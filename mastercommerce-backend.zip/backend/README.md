# Mastercommerce Backend

A free-to-run backend for Mastercommerce. It gives the app three new abilities:

1. **"Thinking"** — a reasoning layer that pulls together your existing
   Accounting/Economics/Maths knowledge base, Wikipedia, and any documents
   you upload, then produces a structured answer. No paid API key is
   required to use this.
2. **Wikipedia lookup** — free, public Wikipedia search/summary endpoints
   (no key needed).
3. **Document upload** — upload PDF, DOCX, TXT, MD or CSV files; the
   backend extracts their text and can pull relevant excerpts into chat
   answers.

## 1. Install

You need [Node.js](https://nodejs.org) 18 or later installed.

```bash
cd mastercommerce-backend
npm install
```

## 2. Configure (optional)

```bash
cp .env.example .env
```

You do **not** need to fill anything in — the backend works fully offline
and for free with the default "local reasoning engine" mode.

If you ever want more natural, conversational phrasing, you can optionally
sign up for a free API key at [console.groq.com](https://console.groq.com)
(no credit card required) and add it to `.env` as `GROQ_API_KEY`. If it's
present, the backend uses it; if not, it silently uses the local engine.
Nothing else about the app changes either way.

## 3. Run

```bash
npm start
```

The server starts on `http://localhost:3000` by default (change `PORT` in
`.env` if needed). Visit `http://localhost:3000/api/health` to confirm it's
running and see which AI mode is active.

## API Reference

### Chat

`POST /api/chat`

```json
{ "message": "Explain gross profit" }
```

Response:

```json
{
  "answer": "<h2>Gross Profit and Net Profit</h2>...",
  "mode": "local",
  "subject": "Accounting",
  "sources": {
    "knowledgeTopic": "Gross Profit and Net Profit",
    "wikipediaTitle": null,
    "documentsUsed": []
  }
}
```

`answer` is HTML, ready to drop into the same `.message` container the
original frontend already uses (`message.innerHTML = answer`).

### Wikipedia

- `GET /api/wikipedia/search?q=inflation` — returns matching page titles/snippets
- `GET /api/wikipedia/summary/Inflation` — returns a plain-text summary for a specific title

### Documents

- `POST /api/documents/upload` — multipart form upload, field name `file`. Accepts `.pdf`, `.docx`, `.txt`, `.md`, `.csv` (max 20MB).
- `GET /api/documents` — list uploaded documents
- `GET /api/documents/search?q=depreciation` — search across uploaded document text
- `DELETE /api/documents/:id` — remove a document

## How "thinking" works without a paid API

For every question, the backend:

1. Detects the likely subject (Accounting / Economics / Mathematics) and
   searches the local knowledge base (ported directly from your existing
   `script.js`).
2. Searches any documents you've uploaded for relevant excerpts.
3. If the question looks like it needs outside context (or explicitly
   mentions Wikipedia), it fetches a summary from Wikipedia.
4. Combines whatever it found into one structured HTML answer.

This "local reasoning engine" is rule-based rather than a true language
model, so it won't generate free-form prose the way GPT or Claude would —
but it reliably grounds every answer in your real knowledge base, your own
documents, and Wikipedia, with zero cost and zero external dependencies at
runtime (aside from reaching Wikipedia's public API).

## Connecting your existing frontend

In your frontend `script.js`, replace the call to the local
`generateAnswer(question)` function with a call to this backend, e.g.:

```javascript
async function generateAnswer(question) {
    const response = await fetch("http://localhost:3000/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: question })
    });

    const data = await response.json();
    return data.answer;
}
```

Since `generateAnswer` is already used as the source of the HTML injected
into each assistant message, this is a drop-in replacement — no other
frontend changes are required for basic chat.

For document upload, you'll want a small file input in the UI that POSTs
to `/api/documents/upload` as `multipart/form-data`.

## Project structure

```
mastercommerce-backend/
├── server.js                 # Express app entry point
├── routes/
│   ├── chat.js                # POST /api/chat
│   ├── wikipedia.js           # GET /api/wikipedia/*
│   └── documents.js           # Upload/list/search/delete documents
├── services/
│   ├── aiService.js           # The "thinking" / reasoning layer
│   ├── knowledgeService.js    # Local knowledge base search
│   ├── wikipediaService.js    # Wikipedia API calls
│   └── documentService.js     # File text extraction, chunking, search
├── data/
│   ├── knowledgeBase.js       # Extracted from the original script.js
│   └── documents.json         # Auto-created index of uploaded docs
└── uploads/                   # Auto-created storage for uploaded files
```
