const express = require("express");
const router = express.Router();
const aiService = require("../services/aiService");

/**
 * POST /api/chat
 * body: { message: string }
 */
router.post("/", async (req, res) => {
  try {
    const { message } = req.body;

    if (!message || typeof message !== "string" || !message.trim()) {
      return res.status(400).json({ error: "A non-empty 'message' string is required." });
    }

    const result = await aiService.answerQuestion(message.trim());

    res.json(result);
  } catch (error) {
    console.error("Chat error:", error);
    res.status(500).json({ error: "Something went wrong generating an answer." });
  }
});

module.exports = router;
