const express = require("express");
const router = express.Router();
const wikipediaService = require("../services/wikipediaService");

/**
 * GET /api/wikipedia/search?q=...
 */
router.get("/search", async (req, res) => {
  try {
    const query = String(req.query.q || "").trim();

    if (!query) {
      return res.status(400).json({ error: "Query parameter 'q' is required." });
    }

    const results = await wikipediaService.searchWikipedia(query);
    res.json({ query, results });
  } catch (error) {
    console.error("Wikipedia search error:", error);
    res.status(502).json({ error: "Could not reach Wikipedia." });
  }
});

/**
 * GET /api/wikipedia/summary/:title
 */
router.get("/summary/:title", async (req, res) => {
  try {
    const title = req.params.title;
    const summary = await wikipediaService.getSummary(title);

    if (!summary) {
      return res.status(404).json({ error: "No summary found for that title." });
    }

    res.json(summary);
  } catch (error) {
    console.error("Wikipedia summary error:", error);
    res.status(502).json({ error: "Could not reach Wikipedia." });
  }
});

module.exports = router;
