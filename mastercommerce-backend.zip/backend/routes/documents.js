const express = require("express");
const multer = require("multer");
const path = require("path");
const router = express.Router();
const documentService = require("../services/documentService");

const ALLOWED_EXTENSIONS = [".pdf", ".docx", ".txt", ".md", ".csv"];
const MAX_FILE_SIZE_MB = 20;

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, documentService.UPLOADS_DIR),
  filename: (req, file, cb) => {
    const safeName = `${Date.now()}-${Math.round(Math.random() * 1e6)}${path.extname(file.originalname)}`;
    cb(null, safeName);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: MAX_FILE_SIZE_MB * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (!ALLOWED_EXTENSIONS.includes(ext)) {
      return cb(new Error(`Unsupported file type "${ext}". Allowed: ${ALLOWED_EXTENSIONS.join(", ")}`));
    }
    cb(null, true);
  }
});

/**
 * POST /api/documents/upload
 * multipart/form-data with a "file" field.
 */
router.post("/upload", (req, res) => {
  upload.single("file")(req, res, async err => {
    if (err) {
      return res.status(400).json({ error: err.message });
    }

    if (!req.file) {
      return res.status(400).json({ error: "No file was uploaded (expected field name 'file')." });
    }

    try {
      const doc = await documentService.addDocument(req.file);
      res.status(201).json({ message: "Document uploaded and indexed.", document: doc });
    } catch (error) {
      console.error("Document processing error:", error);
      res.status(500).json({ error: "Could not extract text from that document." });
    }
  });
});

/**
 * GET /api/documents
 */
router.get("/", (req, res) => {
  res.json({ documents: documentService.listDocuments() });
});

/**
 * DELETE /api/documents/:id
 */
router.delete("/:id", (req, res) => {
  const deleted = documentService.deleteDocument(req.params.id);

  if (!deleted) {
    return res.status(404).json({ error: "Document not found." });
  }

  res.json({ message: "Document deleted." });
});

/**
 * GET /api/documents/search?q=...
 * Search across uploaded documents directly (used for debugging/testing).
 */
router.get("/search", (req, res) => {
  const query = String(req.query.q || "").trim();

  if (!query) {
    return res.status(400).json({ error: "Query parameter 'q' is required." });
  }

  res.json({ query, results: documentService.searchDocuments(query) });
});

module.exports = router;
