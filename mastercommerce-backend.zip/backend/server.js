require("dotenv").config();

const express = require("express");
const cors = require("cors");

const chatRoutes = require("./routes/chat");
const wikipediaRoutes = require("./routes/wikipedia");
const documentRoutes = require("./routes/documents");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: "2mb" }));

app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    aiMode: process.env.GROQ_API_KEY ? "groq (free-tier)" : "local (no key needed)",
    time: new Date().toISOString()
  });
});

app.use("/api/chat", chatRoutes);
app.use("/api/wikipedia", wikipediaRoutes);
app.use("/api/documents", documentRoutes);

app.use((req, res) => {
  res.status(404).json({ error: "Not found." });
});

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "Unexpected server error." });
});

app.listen(PORT, () => {
  console.log(`Mastercommerce backend running on http://localhost:${PORT}`);
  console.log(
    process.env.GROQ_API_KEY
      ? "AI mode: Groq (free-tier API key detected)"
      : "AI mode: Local reasoning engine (no API key needed)"
  );
});
