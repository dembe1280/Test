/**
 * knowledgeService.js
 *
 * Searches the built-in Accounting / Economics / Mathematics knowledge
 * base (the same data used by the original frontend script.js) and
 * detects which subject a question belongs to.
 */

const {
  accountingKnowledge,
  economicsKnowledge,
  mathematicsKnowledge
} = require("../data/knowledgeBase.js");

const subjectWords = {
  Accounting: [
    "accounting", "account", "ifrs", "ias", "audit", "auditing", "tax",
    "vat", "ledger", "debit", "credit", "inventory", "stock", "asset",
    "liability", "equity", "profit", "loss", "depreciation", "cash flow",
    "financial statement", "balance sheet", "income statement", "journal",
    "trial balance", "consolidation", "associate", "subsidiary", "revenue",
    "lease", "partnership", "partner", "company", "companies",
    "share capital", "shares", "dividend", "manufacturing account",
    "prime cost", "factory overheads", "budget", "budgeting",
    "cash budget", "internal control", "internal audit",
    "segregation of duties", "non profit", "npo", "accumulated fund",
    "subscriptions"
  ],
  Economics: [
    "economics", "economy", "scarcity", "opportunity cost", "demand",
    "supply", "equilibrium", "market", "inflation", "unemployment",
    "gdp", "fiscal", "monetary", "sarb", "repo", "elasticity", "elastic",
    "trade", "export", "import", "tariff", "quota", "exchange rate",
    "externality", "aggregate demand", "aggregate supply", "multiplier",
    "circular flow", "leakage", "injection", "market failure",
    "public good", "free rider", "merit good", "demerit good",
    "income distribution", "poverty", "gini", "lorenz curve",
    "inequality", "balance of payments", "current account",
    "economic system", "command economy", "mixed economy"
  ],
  Mathematics: [
    "mathematics", "math", "maths", "algebra", "equation", "quadratic",
    "linear", "calculus", "derivative", "differentiation", "integration",
    "integral", "trigonometry", "sin", "cos", "tan", "statistics",
    "probability", "matrix", "matrices", "sequence", "function",
    "gradient", "pythagoras", "percentage", "fraction", "set", "sets",
    "venn diagram", "union", "intersection", "subset", "exponent",
    "exponents", "surd", "surds", "indices", "inequality", "inequalities",
    "vector", "vectors", "coordinate geometry", "equation of a circle",
    "midpoint", "distance formula", "mensuration", "area", "perimeter",
    "volume", "circumference"
  ]
};

function normalizeText(text) {
  return String(text || "")
    .toLowerCase()
    .replace(/[’']/g, "")
    .replace(/[^a-z0-9%²^.\-\s]/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function getTokens(text) {
  return normalizeText(text).split(/\s+/).filter(Boolean);
}

function detectSubject(question) {
  const text = normalizeText(question);

  const scores = { Accounting: 0, Economics: 0, Mathematics: 0 };

  Object.keys(subjectWords).forEach(subject => {
    subjectWords[subject].forEach(keyword => {
      const key = normalizeText(keyword);
      if (!key) return;
      if (text.includes(key)) {
        scores[subject] += key.includes(" ") ? 8 : 4;
      }
    });
  });

  const sorted = Object.entries(scores).sort((a, b) => b[1] - a[1]);

  if (sorted[0][1] === 0) return null;
  if (sorted[1] && sorted[0][1] === sorted[1][1]) return null;

  return sorted[0][0];
}

function scoreKnowledgeItem(question, item) {
  const text = normalizeText(question);
  const tokens = new Set(getTokens(question));
  let score = 0;

  const topic = normalizeText(item.topic);
  if (text.includes(topic)) score += 60;

  item.keywords.forEach(keyword => {
    const key = normalizeText(keyword);
    if (!key) return;
    if (text.includes(key)) score += key.includes(" ") ? 35 : 25;
  });

  item.keywords.forEach(keyword => {
    const keyTokens = getTokens(keyword);
    let matches = 0;
    keyTokens.forEach(token => {
      if (tokens.has(token)) matches++;
    });
    if (matches > 0) score += matches * 7;
  });

  (item.relatedKeywords || []).forEach(keyword => {
    const key = normalizeText(keyword);
    if (key && text.includes(key)) score += 10;
  });

  const formulaWords = [
    "formula", "calculate", "calculation", "equation", "how much",
    "work out", "find", "compute"
  ];
  formulaWords.forEach(word => {
    if (text.includes(word) && item.formulas.length > 0) score += 10;
  });

  const definitionWords = [
    "what is", "define", "definition", "explain", "meaning", "what does"
  ];
  definitionWords.forEach(word => {
    if (text.includes(word)) score += 3;
  });

  return score;
}

function getKnowledgeForSubject(subject) {
  if (subject === "Accounting") return accountingKnowledge;
  if (subject === "Economics") return economicsKnowledge;
  if (subject === "Mathematics") return mathematicsKnowledge;
  return [];
}

function searchKnowledge(question, subject) {
  const knowledge = getKnowledgeForSubject(subject);
  if (!knowledge.length) return [];

  const scored = knowledge.map(item => ({
    item,
    score: scoreKnowledgeItem(question, item)
  }));

  scored.sort((a, b) => b.score - a.score);

  return scored.filter(result => result.score >= 18).slice(0, 3);
}

/**
 * Search across all subjects (used when the subject can't be
 * confidently detected, or when the caller wants full-corpus recall).
 */
function searchAllKnowledge(question, limit = 3) {
  const all = [
    ...accountingKnowledge.map(item => ({ item, subject: "Accounting" })),
    ...economicsKnowledge.map(item => ({ item, subject: "Economics" })),
    ...mathematicsKnowledge.map(item => ({ item, subject: "Mathematics" }))
  ];

  const scored = all.map(entry => ({
    ...entry,
    score: scoreKnowledgeItem(question, entry.item)
  }));

  scored.sort((a, b) => b.score - a.score);

  return scored.filter(result => result.score >= 18).slice(0, limit);
}

function getTopicList(subject) {
  return getKnowledgeForSubject(subject).map(item => item.topic);
}

module.exports = {
  detectSubject,
  searchKnowledge,
  searchAllKnowledge,
  getTopicList,
  getKnowledgeForSubject,
  accountingKnowledge,
  economicsKnowledge,
  mathematicsKnowledge
};
