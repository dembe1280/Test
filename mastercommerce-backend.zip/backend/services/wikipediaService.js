/**
 * wikipediaService.js
 *
 * Talks to Wikipedia's public API. No API key is required for this —
 * Wikipedia's search and summary endpoints are free and open.
 */

const WIKI_API = "https://en.wikipedia.org/w/api.php";
const WIKI_SUMMARY = "https://en.wikipedia.org/api/rest_v1/page/summary/";

/**
 * Search Wikipedia for pages matching a query.
 * Returns an array of { title, snippet, pageid }.
 */
async function searchWikipedia(query, limit = 5) {
  const url =
    `${WIKI_API}?action=query&list=search&srsearch=${encodeURIComponent(
      query
    )}&format=json&srlimit=${limit}&origin=*`;

  const response = await fetch(url);

  if (!response.ok) {
    throw new Error(`Wikipedia search failed: ${response.status}`);
  }

  const data = await response.json();

  const results = (data?.query?.search || []).map(item => ({
    title: item.title,
    pageid: item.pageid,
    // Wikipedia wraps matched terms in <span class="searchmatch">, strip that
    snippet: String(item.snippet || "").replace(/<\/?span[^>]*>/g, "")
  }));

  return results;
}

/**
 * Fetch a plain-text summary (intro paragraph) for a specific Wikipedia
 * page title. This uses the REST summary endpoint, which returns a
 * clean, short extract ideal for chat answers.
 */
async function getSummary(title) {
  const url = WIKI_SUMMARY + encodeURIComponent(title);

  const response = await fetch(url, {
    headers: { Accept: "application/json" }
  });

  if (!response.ok) {
    return null;
  }

  const data = await response.json();

  if (!data || data.type === "disambiguation") {
    return null;
  }

  return {
    title: data.title,
    extract: data.extract,
    url: data.content_urls?.desktop?.page || null,
    thumbnail: data.thumbnail?.source || null
  };
}

/**
 * Convenience helper used by the chat engine: search for the best
 * matching page for a question, then fetch its summary.
 */
async function lookup(query) {
  const results = await searchWikipedia(query, 3);

  if (!results.length) {
    return null;
  }

  // Try the top result first; if it's a disambiguation page or fails,
  // fall back to the next result.
  for (const result of results) {
    const summary = await getSummary(result.title);
    if (summary && summary.extract) {
      return summary;
    }
  }

  return null;
}

module.exports = {
  searchWikipedia,
  getSummary,
  lookup
};
