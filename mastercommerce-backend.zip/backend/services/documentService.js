/**
 * documentService.js
 *
 * Handles uploaded documents: extracting their text (PDF, DOCX, TXT),
 * storing a lightweight index on disk (data/documents.json), and
 * searching across them so the chat engine can pull relevant excerpts
 * into its answers.
 */

const fs = require("fs");
const path = require("path");
const pdfParse = require("pdf-parse");
const mammoth = require("mammoth");

const DATA_DIR = path.join(__dirname, "..", "data");
const UPLOADS_DIR = path.join(__dirname, "..", "uploads");
const INDEX_FILE = path.join(DATA_DIR, "documents.json");

function ensureStorage() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  if (!fs.existsSync(INDEX_FILE)) fs.writeFileSync(INDEX_FILE, "[]");
}

function loadIndex() {
  ensureStorage();
  try {
    return JSON.parse(fs.readFileSync(INDEX_FILE, "utf8"));
  } catch (error) {
    return [];
  }
}

function saveIndex(index) {
  ensureStorage();
  fs.writeFileSync(INDEX_FILE, JSON.stringify(index, null, 2));
}

/**
 * Extract plain text from a file buffer, based on its extension.
 */
async function extractText(filePath, originalName) {
  const ext = path.extname(originalName).toLowerCase();

  if (ext === ".pdf") {
    const buffer = fs.readFileSync(filePath);
    const parsed = await pdfParse(buffer);
    return parsed.text || "";
  }

  if (ext === ".docx") {
    const result = await mammoth.extractRawText({ path: filePath });
    return result.value || "";
  }

  if (ext === ".txt" || ext === ".md" || ext === ".csv") {
    return fs.readFileSync(filePath, "utf8");
  }

  throw new Error(
    `Unsupported file type "${ext}". Supported types: .pdf, .docx, .txt, .md, .csv`
  );
}

/**
 * Split extracted text into overlapping chunks so search can return
 * focused excerpts instead of an entire document.
 */
function chunkText(text, chunkSize = 800, overlap = 150) {
  const clean = text.replace(/\s+/g, " ").trim();
  const chunks = [];

  let start = 0;
  while (start < clean.length) {
    const end = Math.min(start + chunkSize, clean.length);
    chunks.push(clean.slice(start, end));
    if (end === clean.length) break;
    start = end - overlap;
  }

  return chunks;
}

/**
 * Register a newly uploaded file: extract its text, chunk it, and
 * save it to the index.
 */
async function addDocument(file) {
  const text = await extractText(file.path, file.originalname);
  const chunks = chunkText(text);

  const index = loadIndex();

  const doc = {
    id: `${Date.now()}-${Math.round(Math.random() * 1e6)}`,
    filename: file.originalname,
    storedAs: path.basename(file.path),
    uploadedAt: new Date().toISOString(),
    sizeBytes: file.size,
    chunkCount: chunks.length,
    chunks
  };

  index.push(doc);
  saveIndex(index);

  return {
    id: doc.id,
    filename: doc.filename,
    uploadedAt: doc.uploadedAt,
    sizeBytes: doc.sizeBytes,
    chunkCount: doc.chunkCount
  };
}

function listDocuments() {
  return loadIndex().map(doc => ({
    id: doc.id,
    filename: doc.filename,
    uploadedAt: doc.uploadedAt,
    sizeBytes: doc.sizeBytes,
    chunkCount: doc.chunkCount
  }));
}

function deleteDocument(id) {
  const index = loadIndex();
  const doc = index.find(item => item.id === id);

  if (!doc) return false;

  const filePath = path.join(UPLOADS_DIR, doc.storedAs);
  if (fs.existsSync(filePath)) fs.unlinkSync(filePath);

  const next = index.filter(item => item.id !== id);
  saveIndex(next);

  return true;
}

/**
 * Very simple keyword-overlap search across all stored document
 * chunks. Returns the best-matching chunks with a relevance score,
 * so the chat engine can quote relevant excerpts back to the user.
 */
function searchDocuments(query, limit = 3) {
  const index = loadIndex();

  const queryTokens = query
    .toLowerCase()
    .replace(/[^a-z0-9\s]/gi, " ")
    .split(/\s+/)
    .filter(token => token.length > 2);

  if (!queryTokens.length) return [];

  const results = [];

  index.forEach(doc => {
    doc.chunks.forEach((chunk, chunkIndex) => {
      const lowerChunk = chunk.toLowerCase();
      let score = 0;

      queryTokens.forEach(token => {
        if (lowerChunk.includes(token)) score += 1;
      });

      if (score > 0) {
        results.push({
          documentId: doc.id,
          filename: doc.filename,
          chunkIndex,
          score,
          excerpt: chunk
        });
      }
    });
  });

  results.sort((a, b) => b.score - a.score);

  return results.slice(0, limit);
}

module.exports = {
  addDocument,
  listDocuments,
  deleteDocument,
  searchDocuments,
  UPLOADS_DIR
};
