/**
 * aiService.js
 *
 * This is the "thinking" layer. It gathers relevant context from three
 * sources — the local knowledge base, Wikipedia, and any documents the
 * user has uploaded — then produces an answer.
 *
 * Two modes:
 *   1. LOCAL MODE (default, always free): a rule-based composer stitches
 *      the retrieved context into a clear, well-structured answer. No
 *      external API or key is required.
 *   2. GROQ MODE (optional upgrade): if a GROQ_API_KEY is set in .env,
 *      the same retrieved context is handed to Groq's free-tier LLM API
 *      (OpenAI-compatible) to produce more natural, conversational
 *      phrasing. Groq's free tier does not require a credit card, but
 *      it is still an external third-party service, so it stays fully
 *      optional.
 */

const knowledgeService = require("./knowledgeService");
const wikipediaService = require("./wikipediaService");
const documentService = require("./documentService");

const GROQ_API_KEY = process.env.GROQ_API_KEY || "";
const GROQ_MODEL = process.env.GROQ_MODEL || "llama-3.1-8b-instant";
const GROQ_URL = "https://api.groq.com/openai/v1/chat/completions";

/**
 * Decide whether a question looks like it wants outside/general
 * knowledge (a good candidate for a Wikipedia lookup) rather than a
 * pure curriculum question already well covered locally.
 */
function shouldConsultWikipedia(question, localResults) {
  const text = question.toLowerCase();

  const explicitWikiRequest =
    text.includes("wikipedia") || text.includes("look up") || text.includes("search for");

  // If local knowledge already answered confidently, only go to
  // Wikipedia if explicitly asked.
  if (localResults.length && localResults[0].score >= 60 && !explicitWikiRequest) {
    return false;
  }

  return true;
}

/**
 * Gather all available context for a question: local knowledge base
 * matches, an optional Wikipedia summary, and any matching excerpts
 * from uploaded documents.
 */
async function gatherContext(question) {
  const subject = knowledgeService.detectSubject(question);

  let localResults = subject
    ? knowledgeService.searchKnowledge(question, subject)
    : knowledgeService.searchAllKnowledge(question);

  const docResults = documentService.searchDocuments(question, 3);

  let wiki = null;
  if (shouldConsultWikipedia(question, localResults)) {
    try {
      wiki = await wikipediaService.lookup(question);
    } catch (error) {
      wiki = null; // fail silently — Wikipedia being unreachable shouldn't break chat
    }
  }

  return { subject, localResults, docResults, wiki };
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

/**
 * LOCAL MODE: compose a structured HTML answer directly from the
 * gathered context, without calling any external AI.
 */
function composeLocalAnswer(question, context) {
  const { localResults, docResults, wiki } = context;
  let html = "";
  let usedSomething = false;

  if (localResults.length) {
    const best = localResults[0].item;
    usedSomething = true;

    html += `<h2>${escapeHtml(best.topic)}</h2>`;
    html += `<p>${escapeHtml(best.information)}</p>`;

    if (best.formulas && best.formulas.length) {
      html += `<h3>Formula${best.formulas.length > 1 ? "s" : ""}</h3>`;
      best.formulas.forEach(formula => {
        html += `<div class="formula">${escapeHtml(formula)}</div>`;
      });
    }

    if (best.rules && best.rules.length) {
      html += `<h3>Key points</h3><ul>`;
      best.rules.forEach(rule => {
        html += `<li>${escapeHtml(rule)}</li>`;
      });
      html += `</ul>`;
    }

    if (best.examples && best.examples.length) {
      html += `<h3>Example${best.examples.length > 1 ? "s" : ""}</h3>`;
      best.examples.forEach(example => {
        html += `<div class="example-box">${escapeHtml(example)}</div>`;
      });
    }
  }

  if (docResults.length) {
    usedSomething = true;
    html += `<h3>From your uploaded documents</h3>`;
    docResults.forEach(result => {
      html += `
        <div class="doc-excerpt">
          <strong>${escapeHtml(result.filename)}</strong>
          <p>${escapeHtml(result.excerpt)}</p>
        </div>
      `;
    });
  }

  if (wiki && wiki.extract) {
    usedSomething = true;
    html += `<h3>From Wikipedia — ${escapeHtml(wiki.title)}</h3>`;
    html += `<p>${escapeHtml(wiki.extract)}</p>`;
    if (wiki.url) {
      html += `<p><a href="${escapeHtml(wiki.url)}" target="_blank" rel="noopener">Read more on Wikipedia</a></p>`;
    }
  }

  if (!usedSomething) {
    html += `
      <p>I could not find specific information about that in my knowledge base, your uploaded documents, or Wikipedia.</p>
      <p>Try rephrasing the question, mentioning the exact topic name, or uploading a document that covers it.</p>
    `;
  }

  return html;
}

/**
 * GROQ MODE: send the gathered context to Groq's free-tier LLM so it
 * can produce a more natural, conversational answer. Falls back to
 * the local composer automatically if the call fails for any reason.
 */
async function composeGroqAnswer(question, context) {
  const { localResults, docResults, wiki } = context;

  const contextPieces = [];

  if (localResults.length) {
    const best = localResults[0].item;
    contextPieces.push(
      `Knowledge base topic "${best.topic}": ${best.information} ` +
        `Formulas: ${best.formulas.join("; ") || "none"}. ` +
        `Key points: ${best.rules.join(" ") || "none"}.`
    );
  }

  docResults.forEach(result => {
    contextPieces.push(
      `Excerpt from uploaded document "${result.filename}": ${result.excerpt}`
    );
  });

  if (wiki && wiki.extract) {
    contextPieces.push(`Wikipedia summary of "${wiki.title}": ${wiki.extract}`);
  }

  const systemPrompt =
    "You are Mastercommerce, a study assistant for Accounting, Economics and Mathematics. " +
    "Answer the user's question clearly and concisely using the provided context where relevant. " +
    "If the context doesn't cover the question, answer from your own knowledge but say so. " +
    "Format your answer as clean HTML using <h2>, <h3>, <p>, <ul>/<li>, and <div class=\"formula\"> for formulas.";

  const userPrompt =
    `Question: ${question}\n\n` +
    (contextPieces.length
      ? `Relevant context:\n${contextPieces.join("\n\n")}`
      : "No additional context was found; answer from your own knowledge.");

  const response = await fetch(GROQ_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${GROQ_API_KEY}`
    },
    body: JSON.stringify({
      model: GROQ_MODEL,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ],
      temperature: 0.4,
      max_tokens: 700
    })
  });

  if (!response.ok) {
    throw new Error(`Groq API request failed: ${response.status}`);
  }

  const data = await response.json();
  const content = data?.choices?.[0]?.message?.content;

  if (!content) {
    throw new Error("Groq API returned no content");
  }

  return content;
}

/**
 * Main entry point: answer a question using whichever mode is
 * available, always falling back to the free local engine.
 */
async function answerQuestion(question) {
  const context = await gatherContext(question);

  let answer;
  let mode = "local";

  if (GROQ_API_KEY) {
    try {
      answer = await composeGroqAnswer(question, context);
      mode = "groq";
    } catch (error) {
      answer = composeLocalAnswer(question, context);
      mode = "local (groq unavailable)";
    }
  } else {
    answer = composeLocalAnswer(question, context);
  }

  return {
    answer,
    mode,
    subject: context.subject,
    sources: {
      knowledgeTopic: context.localResults[0]?.item?.topic || null,
      wikipediaTitle: context.wiki?.title || null,
      documentsUsed: context.docResults.map(result => result.filename)
    }
  };
}

module.exports = {
  answerQuestion,
  gatherContext,
  composeLocalAnswer
};
